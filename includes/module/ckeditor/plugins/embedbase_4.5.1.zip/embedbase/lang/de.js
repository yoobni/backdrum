/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'de', {
	pathName: 'Medienobjekt',
	title: 'Media Embed', // MISSING
	button: 'Insert Media Embed', // MISSING
	unsupportedUrlGiven: 'Die angegebene URL wird nicht unterstützt.',
	unsupportedUrl: 'The URL {url} is not supported by Media Embed.', // MISSING
	fetchingFailedGiven: 'Abrufen des Inhalts für die angegebene URL ist fehlgeschlagen.',
	fetchingFailed: 'Abrufen des Inhalts für {url} ist fehlgeschlagen.',
	fetchingOne: 'Fetching oEmbed response...', // MISSING
	fetchingMany: 'Fetching oEmbed responses, {current} of {max} done...' // MISSING
} );
