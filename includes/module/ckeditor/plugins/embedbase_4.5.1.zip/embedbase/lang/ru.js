/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'ru', {
	pathName: 'media object', // MISSING
	title: 'Media Embed', // MISSING
	button: 'Вставить медиаконтент',
	unsupportedUrlGiven: 'The specified URL is not supported.', // MISSING
	unsupportedUrl: 'URL {url} не поддерживает возможность вставки медиаконтента',
	fetchingFailedGiven: 'Не удалось извлечь контент для заданного URL',
	fetchingFailed: 'Не удалось извлечь контент для {url}',
	fetchingOne: 'Fetching oEmbed response...', // MISSING
	fetchingMany: 'Fetching oEmbed responses, {current} of {max} done...' // MISSING
} );
